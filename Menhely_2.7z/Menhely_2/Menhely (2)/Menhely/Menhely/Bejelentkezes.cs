using System.IO;
namespace Menhely
{
    
    public partial class Bejelentkezes : Template
    {
        public Bejelentkezes()
        {
            InitializeComponent();            
        }

        Adatbazis adatbazis = new Adatbazis();

        private void Login_Click(object sender, EventArgs e)
        {
            bool sikeresBel�p�sFlag = false;
            try
            {
                StreamReader belepes = new StreamReader("felhasznalok.txt");
                while (belepes.EndOfStream == false)
                {
                    String sor = belepes.ReadLine();
                    String[] szavak = sor.Split(' ');
                    String nev = szavak[0];
                    String jelszo = szavak[1];
                    if (Jelszo.Text == nev &&
                        Felhasznalo.Text == jelszo
                        )
                    {
                        sikeresBel�p�sFlag = true;
                        break;
                    }
                }
                if (sikeresBel�p�sFlag == false)
                {
                    MessageBox.Show("Csak jogosult felhaszn�l�k sz�m�ra!");
                }
                belepes.Close();
            }
            catch (Exception ex) { MessageBox.Show("Hiba: " + ex); }
            if (sikeresBel�p�sFlag == true)
            {
                this.Hide();
                adatbazis.Show();
            }
        }        
        private void Bejelentkezes_Load(object sender, EventArgs e)
        {
            adatbazis = new Adatbazis();
        }

        private void Bejelentkezes_Activated(object sender, EventArgs e)
        {
            if (adatbazis != null)
            {
                if (adatbazis.DialogResult == DialogResult.OK)
                {
                    Felhasznalo.Text = "";
                }
                if (adatbazis.DialogResult == DialogResult.Cancel)
                {
                    Jelszo.Text = "";
                    Felhasznalo.Text = "";
                }
            }
        }
    }
}