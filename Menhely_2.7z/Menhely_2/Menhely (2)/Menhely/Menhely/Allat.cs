﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Menhely
{
    public class Allat
    {
        protected String fajta;
        protected String szin;
        protected double kor;
        protected String nev;
        protected String kedvencJatek;
        protected String bekerulesiDatum;

        public String Fajta { get { return fajta; } }
        public String Szin { get { return szin; } }
        public double Kor { get { return kor; } }
        public String Nev {  get { return nev; } }
        public String KedvencJatek { get { return kedvencJatek; } }

        public string BekerulesiDatum { get {  return bekerulesiDatum; } }

        public Allat(string fajta, string szin, double kor, string nev, string kedvencjatek, string bekerulesiDatum)
        {
            this.fajta = fajta;
            this.szin = szin;
            this.kor = kor;
            this.nev = nev;
            this.kedvencJatek = kedvencjatek;
            this.bekerulesiDatum = bekerulesiDatum;

        }
        
    }

    public class Macska : Allat
    {
        private double alvasigeny;

        public double Alvasigeny { get { return alvasigeny; } }
        public Macska(string fajta, string szin, double kor, string nev, string kedvencjatek, double alvasigeny, string bekerulesiDatum) : base(fajta, szin, kor, nev, kedvencjatek, bekerulesiDatum)
        {
            this.alvasigeny = alvasigeny;
        }
        public override string ToString()
        {
            return "Fajtája: " + fajta +
                   " Színe: " + szin +
                   " Éves: " + kor + " Neve: " +
                   nev + " Játékszere: " + kedvencJatek + " Alvasigeny: " + alvasigeny; ;
        }

       
    }

    internal class Kutya : Allat
    {
        private double mozgasigeny;

        public double Mozgasigeny { get { return mozgasigeny; } }
        public Kutya(string fajta, string szin, double kor, string nev, string kedvencjatek, double mozgasigeny, string bekerulesiDatum) : base(fajta, szin, kor, nev, kedvencjatek, bekerulesiDatum)
        {
            this.fajta = fajta;
            this.szin = szin;
            this.kor = kor;
            this.nev = nev;
            this.kedvencJatek = kedvencjatek;
            this.mozgasigeny = mozgasigeny;
        }

        public override string ToString()
        {
            return "Fajtája: " + fajta +
                   " Színe: " + szin +
                   " Kora: " + kor + " Neve: " +
                   nev + " Játékszere: " + kedvencJatek + " Mozgásigénye: " + mozgasigeny;
        }
    }
}
