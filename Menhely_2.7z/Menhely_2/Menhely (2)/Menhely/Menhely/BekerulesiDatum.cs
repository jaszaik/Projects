﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Menhely
{
    public partial class BekerulesiDatum : Form
    {
        public BekerulesiDatum(Allat a)
        {
            InitializeComponent();
            textBox1.Text = a.BekerulesiDatum.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
