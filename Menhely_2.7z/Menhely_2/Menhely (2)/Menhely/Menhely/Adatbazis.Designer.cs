﻿namespace Menhely
{
    partial class Adatbazis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            comboBox1 = new ComboBox();
            listBox1 = new ListBox();
            textBox1 = new TextBox();
            button1 = new Button();
            openFileDialog1 = new OpenFileDialog();
            beolvasas = new Button();
            menuStrip1 = new MenuStrip();
            elérhetőségToolStripMenuItem = new ToolStripMenuItem();
            telefonszámToolStripMenuItem = new ToolStripMenuItem();
            emailToolStripMenuItem = new ToolStripMenuItem();
            kilépésToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Segoe UI", 11F);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "kutya", "macska" });
            comboBox1.Location = new Point(1754, 51);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 33);
            comboBox1.TabIndex = 0;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // listBox1
            // 
            listBox1.Font = new Font("Segoe UI", 11F);
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 25;
            listBox1.Location = new Point(42, 109);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(1284, 554);
            listBox1.TabIndex = 1;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(1361, 324);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(524, 27);
            textBox1.TabIndex = 2;
            // 
            // button1
            // 
            button1.Location = new Point(1559, 415);
            button1.Name = "button1";
            button1.Size = new Size(106, 45);
            button1.TabIndex = 3;
            button1.Text = "Adatfelvitel";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            openFileDialog1.FileOk += openFileDialog1_FileOk;
            // 
            // beolvasas
            // 
            beolvasas.Location = new Point(597, 720);
            beolvasas.Name = "beolvasas";
            beolvasas.Size = new Size(134, 45);
            beolvasas.TabIndex = 4;
            beolvasas.Text = "Beolvasás";
            beolvasas.UseVisualStyleBackColor = true;
            beolvasas.Click += beolvasas_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { elérhetőségToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(6, 3, 0, 3);
            menuStrip1.Size = new Size(1920, 38);
            menuStrip1.TabIndex = 5;
            menuStrip1.Text = "menuStrip1";
            // 
            // elérhetőségToolStripMenuItem
            // 
            elérhetőségToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { telefonszámToolStripMenuItem, emailToolStripMenuItem, kilépésToolStripMenuItem });
            elérhetőségToolStripMenuItem.Font = new Font("Segoe UI", 12F);
            elérhetőségToolStripMenuItem.Name = "elérhetőségToolStripMenuItem";
            elérhetőségToolStripMenuItem.Size = new Size(76, 32);
            elérhetőségToolStripMenuItem.Text = "Menü";
            // 
            // telefonszámToolStripMenuItem
            // 
            telefonszámToolStripMenuItem.Name = "telefonszámToolStripMenuItem";
            telefonszámToolStripMenuItem.Size = new Size(204, 32);
            telefonszámToolStripMenuItem.Text = "Telefonszám";
            telefonszámToolStripMenuItem.Click += telefonszámToolStripMenuItem_Click;
            // 
            // emailToolStripMenuItem
            // 
            emailToolStripMenuItem.Name = "emailToolStripMenuItem";
            emailToolStripMenuItem.Size = new Size(204, 32);
            emailToolStripMenuItem.Text = "E-mail";
            emailToolStripMenuItem.Click += emailToolStripMenuItem_Click;
            // 
            // kilépésToolStripMenuItem
            // 
            kilépésToolStripMenuItem.Name = "kilépésToolStripMenuItem";
            kilépésToolStripMenuItem.Size = new Size(204, 32);
            kilépésToolStripMenuItem.Text = "Kilépés";
            kilépésToolStripMenuItem.Click += kilépésToolStripMenuItem_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F);
            label1.Location = new Point(1361, 109);
            label1.Name = "label1";
            label1.Size = new Size(197, 41);
            label1.TabIndex = 6;
            label1.Text = "Lista bővítése";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 18F);
            label2.Location = new Point(42, 51);
            label2.Name = "label2";
            label2.Size = new Size(415, 41);
            label2.TabIndex = 7;
            label2.Text = "Menhelyen tartózkodó állatok";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(1361, 189);
            label3.Name = "label3";
            label3.Size = new Size(406, 25);
            label3.TabIndex = 8;
            label3.Text = "Kérem az állat adatait ;-vel elválasztva vigye fel";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F);
            label4.Location = new Point(1361, 247);
            label4.Name = "label4";
            label4.Size = new Size(428, 25);
            label4.TabIndex = 9;
            label4.Text = "Pl.: M;Perzsa;Vörös;4;Nudli;Madzag;12;01-05-2024";
            // 
            // button2
            // 
            button2.Location = new Point(1513, 500);
            button2.Name = "button2";
            button2.Size = new Size(213, 41);
            button2.TabIndex = 10;
            button2.Text = "bekerulesiDatum";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(1464, 616);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 11;
            button3.Text = "Törlés";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(1731, 616);
            button4.Name = "button4";
            button4.Size = new Size(94, 29);
            button4.TabIndex = 12;
            button4.Text = "Frissít";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // Adatbazis
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1920, 793);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(beolvasas);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Controls.Add(listBox1);
            Controls.Add(comboBox1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Adatbazis";
            Text = "Form2";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comboBox1;
        private ListBox listBox1;
        private TextBox textBox1;
        private Button button1;
        private OpenFileDialog openFileDialog1;
        private Button beolvasas;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem elérhetőségToolStripMenuItem;
        private ToolStripMenuItem telefonszámToolStripMenuItem;
        private ToolStripMenuItem emailToolStripMenuItem;
        private Label label1;
        private Label label2;
        private ToolStripMenuItem kilépésToolStripMenuItem;
        private Label label3;
        private Label label4;
        private Button button2;
        private Button button3;
        private Button button4;
    }
}