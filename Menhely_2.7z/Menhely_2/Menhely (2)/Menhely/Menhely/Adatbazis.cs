﻿using System.IO;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;
using System.Diagnostics.Eventing.Reader;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Reflection;

namespace Menhely
{
    public partial class Adatbazis : Template
    {

        public Adatbazis()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String ujAllat = textBox1.Text;
            if (ujAllat.Length > 0)
            {
                String[] ujAllatok = ujAllat.Split(';');
                if (ujAllatok[0] == "K")
                {
                    Kutya k1 = new Kutya(ujAllatok[1],
                                               Convert.ToString(ujAllatok[2]),
                                               Convert.ToDouble(ujAllatok[3]),
                                               Convert.ToString(ujAllatok[4]),
                                               Convert.ToString(ujAllatok[5]),
                                               Convert.ToDouble(ujAllatok[6]),
                                               Convert.ToString(ujAllatok[7]));
                    kutyak.Add(k1);
                    listBox1.Items.Add(k1);
                }
                else
                {
                    Macska m1 = new Macska(ujAllatok[1],
                                               Convert.ToString(ujAllatok[2]),
                                               Convert.ToDouble(ujAllatok[3]),
                                               Convert.ToString(ujAllatok[4]),
                                               Convert.ToString(ujAllatok[5]),
                                               Convert.ToDouble(ujAllatok[6]),
                                               Convert.ToString(ujAllatok[7]));


                    macskak.Add(m1);
                    listBox1.Items.Add(m1);
                }
                string fileTartalom = "";
                using (StreamReader sr = new StreamReader(openFileDialog1.FileName))
                {
                    sr.ReadLine();
                    while (!sr.EndOfStream)
                    {
                        sr.ReadLine();
                    }
                }

                using (StreamWriter sw = new StreamWriter(openFileDialog1.FileName, true))
                {
                    sw.Write(fileTartalom);
                    sw.Write("\n" + ujAllat);
                }//új sor hozzáadása a txt-fájlhoz

            }
            textBox1.Text = "";
            // saját adat felvitele a textboxból a listboxba            
        }

        private void beolvasas_Click(object sender, EventArgs e)
        {
            listBox1.Text = Convert.ToString(openFileDialog1.ShowDialog(this));
        }

        private List<Kutya> kutyak = new List<Kutya>();
        private List<Macska> macskak = new List<Macska>();
        public void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            string fileTartalom = "";
            String fileNev = openFileDialog1.FileName;
            if (fileNev != null)
            {
                StreamReader sr = null;
                try
                {
                    sr = new StreamReader(fileNev);
                    sr.ReadLine();
                    while (!sr.EndOfStream)
                    {

                        String line = sr.ReadLine();
                        String[] allatMenhely = line.Split(';');
                        if (allatMenhely[0] == "K")
                        {
                            Kutya k1 = new Kutya(allatMenhely[1],
                                               Convert.ToString(allatMenhely[2]),
                                               Convert.ToDouble(allatMenhely[3]),
                                               Convert.ToString(allatMenhely[4]),
                                               Convert.ToString(allatMenhely[5]),
                                               Convert.ToDouble(allatMenhely[6]),
                                               Convert.ToString(allatMenhely[7]));

                            kutyak.Add(k1);
                            listBox1.Items.Add(k1);
                        }

                        else
                        {
                            Macska m1 = new Macska(allatMenhely[1],
                                               Convert.ToString(allatMenhely[2]),
                                               Convert.ToDouble(allatMenhely[3]),
                                               Convert.ToString(allatMenhely[4]),
                                               Convert.ToString(allatMenhely[5]),
                                               Convert.ToDouble(allatMenhely[6]),
                                               Convert.ToString(allatMenhely[7]));

                            macskak.Add(m1);
                            listBox1.Items.Add(m1);
                        }
                    }
                }
                catch (IOException)
                {
                    MessageBox.Show("Hibás vagy sérült file," +
                        "kérem, próbálja újra");
                }
                finally
                {
                    if (sr != null) { sr.Close(); }
                }

            }//fájlból való beolvasás list-box feltöltése
        }

        private void telefonszámToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Telefonszam: +36/30-993-3214");
        }

        private void emailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("E-mail cím: vanhely@gmail.com");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            if (comboBox1.SelectedIndex == 0)
            {
                foreach (var kutya in kutyak)
                {
                    listBox1.Items.Add(kutya);
                }
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                foreach (var macska in macskak)
                {
                    listBox1.Items.Add(macska);
                }
            }
            // listbox szűrése a kutyák és macskák alapján

        }

        private void kilépésToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Bejelentkezes myForm1 = new Bejelentkezes();
            myForm1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                Allat a = listBox1.SelectedItem as Allat;
                BekerulesiDatum bekerulesiDatum = new BekerulesiDatum(a);
                bekerulesiDatum.Show();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            }

            else
            {
                MessageBox.Show("Kérlek válassz ki egy elemet törléshez");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int index = listBox1.SelectedIndex;
            if (index >= 0)
            {
                listBox1.Items[index] = textBox1.Text;
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Object item = listBox1.SelectedItem;
            if (item != null)
            {
                String s = item.ToString();
                textBox1.Text = s;
            }
        }
    }// Az "adatbázisból"(form2-ből) kilépés a "bejelentkezési oldalra"(form1-re)
}
